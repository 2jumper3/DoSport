//
//  ViewController.swift
//  DoSport
//
//  Created by Sergey on 18.12.2020.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = Colors.darkBlue
        let text = Fonts.sfProNormal(size: 12)
    }
    //Please add new UIControllers in \Flow\
    //all appColors in \helpers\extensions\colors
    //please provide comments
    //only 1 font in app \\helpers\fonts
    
}

