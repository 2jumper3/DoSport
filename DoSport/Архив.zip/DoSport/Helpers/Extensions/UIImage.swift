//
//  UIImage.swift
//  DoSport
//
//  Created by Sergey on 18.12.2020.
//

import Foundation
import UIKit

public enum Images {
    static func outlinedEllipse(size: CGSize, color: UIColor, lineWidth: CGFloat = 1.5) -> UIImage? {

        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
        guard let context = UIGraphicsGetCurrentContext() else {
            return nil
        }
        context.setStrokeColor(color.cgColor)
        context.setLineWidth(lineWidth)
        let rect = CGRect(origin: .zero, size: size).insetBy(dx: lineWidth * 0.5, dy: lineWidth * 0.5)
        context.addEllipse(in: rect)
        context.strokePath()
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }

}
