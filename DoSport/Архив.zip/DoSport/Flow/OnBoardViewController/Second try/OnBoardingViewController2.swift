//
//  OnBoardingViewController2.swift
//  DoSport
//
//  Created by Sergey on 20.12.2020.
//

import Foundation
import UIKit

class OnBoardingViewController2: UIViewController, UIScrollViewDelegate {
    
    let pageControl1 = FlexiblePageControl()

    let scrollView = UIScrollView()
    let scrollSize: CGFloat = 400

    override func viewDidLoad() {
        super.viewDidLoad()
        
        scrollView.delegate = self
        scrollView.frame = CGRect(x: 0, y: 0, width: scrollSize, height: scrollSize)
        scrollView.center = view.center
        scrollView.isPagingEnabled = true

        pageControl1.center = CGPoint(x: scrollView.center.x, y: scrollView.frame.maxY + 16)

        view.addSubview(scrollView)
        view.addSubview(pageControl1)

        setContent(numberOfPages: 100)
    }
    
    func setContent(numberOfPages: Int) {
        
        var pages: [OnBoardingModel] = [
            OnBoardingModel(image:Icons.onboardingIcons.firstIcon, textHeader: Texts.onBoardingText.headers.firstSlideText, textDescription: Texts.onBoardingText.description.firstSlideText),
            OnBoardingModel(image: Icons.onboardingIcons.secondIcon, textHeader: Texts.onBoardingText.headers.secondSlideText, textDescription: Texts.onBoardingText.description.secondSlideText),
            OnBoardingModel(image: Icons.onboardingIcons.thirdIcon, textHeader: Texts.onBoardingText.headers.thirdSlideText, textDescription: Texts.onBoardingText.description.thirdSlideText),
            OnBoardingModel(image: Icons.onboardingIcons.fourthIcon, textHeader: Texts.onBoardingText.headers.fourthSlideText, textDescription: Texts.onBoardingText.description.fourthSlideText)
        ]

        scrollView.subviews.forEach { $0.removeFromSuperview() }
        
        scrollView.contentSize = CGSize(width: scrollSize * CGFloat(numberOfPages), height: scrollSize)
        pageControl1.numberOfPages = numberOfPages
        
        for index in  0..<numberOfPages {
            let view = UIImageView(
                frame: .init(
                    x: CGFloat(index) * scrollSize,
                    y: 0,
                    width: scrollSize,
                    height: scrollSize
                )
            )
            let imageNamed = NSString(format: "image%02d.jpg", index % 10) as String
            view.image = UIImage(named: imageNamed)
//            view.addSubview(pages[index].image)
            scrollView.addSubview(view)
        }

    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        setContent(numberOfPages: 10)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        pageControl1.setProgress(contentOffsetX: scrollView.contentOffset.x, pageWidth: scrollView.bounds.width)
    }
}
