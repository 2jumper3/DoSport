//
//  PageControl.swift
//  DoSport
//
//  Created by Sergey on 18.12.2020.
//

import Foundation
import UIKit

class PageControl: UIPageControl {

    var pageCount: Int
    init(pageCount: Int) {
        self.pageCount = pageCount
        super.init(frame: .zero)
        currentPage = 0
        numberOfPages = pageCount
        let image = Images.outlinedEllipse(size: CGSize(width: 8.0, height: 8.0), color: .lightGray)
//        pageIndicatorTintColor = UIColor.init(patternImage: image!)
//        currentPageIndicatorTintColor = .lightGray
        pageIndicatorTintColor = .lightGray
        currentPageIndicatorTintColor = UIColor.init(patternImage: image!)
        

        subviews.forEach {
            $0.transform = CGAffineTransform(scaleX: 1, y: 1)
        }
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
